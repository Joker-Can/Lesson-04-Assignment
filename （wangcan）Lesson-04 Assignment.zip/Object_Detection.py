import numpy as np
import cv2
from matplotlib import pyplot as plt

template_image = '12.jpg'
detect_image = '34.jpg'
min_goodmatch_count = 10
min_rightmatch_count = 7
match_threshold = 0.8

src_img = cv2.imread(template_image, 0)
dst_img = cv2.imread(detect_image, 0)

sift = cv2.xfeatures2d.SIFT_create()
kp1, des1 = sift.detectAndCompute(src_img, None)
kp2, des2 = sift.detectAndCompute(dst_img, None)

FLANN_INDEX_KDTREE = 0
index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
search_params = dict(checks=50)

flann = cv2.FlannBasedMatcher(index_params, search_params)

matches = flann.knnMatch(des1, des2, k=2)

good = []
for m, n in matches:
    if m.distance < match_threshold * n.distance:
        good.append(m)

if len(good) > min_goodmatch_count:
    src_pts = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    dst_pts = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)

    # 计算单应性矩阵，同时使用ransac剔除误识别点
    M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
    matchesMask = mask.ravel().tolist()
    rightmatch_count = sum(matchesMask)

    # 映射
    h, w = src_img.shape
    src_corner_pts = np.float32([[0, 0], [0, h - 1], [w - 1, h - 1], [w - 1, 0]]).reshape(-1, 1, 2)
    dst_map_pts = cv2.perspectiveTransform(src_corner_pts, M)

    # 绘制方框
    dst_img = cv2.polylines(dst_img, [np.int32(dst_map_pts)], True, 255, 3, cv2.LINE_AA)
else:
    print("匹配错误，找不到足够的点 - %d/%d" % (len(good), min_goodmatch_count))
    matchesMask = None

if rightmatch_count < min_rightmatch_count:
    print("匹配错误，没有足够的点- %d/%d" % (rightmatch_count, min_rightmatch_count))
else:
    print("匹配成功， 有 %d 正确匹配点" % rightmatch_count)

draw_params = dict(matchColor=(0, 255, 0), singlePointColor=None, matchesMask=matchesMask, flags=2)

img3 = cv2.drawMatches(src_img, kp1, dst_img, kp2, good, None, **draw_params)

plt.imshow(img3, 'gray'), plt.show()
